import React from 'react';
import { Navigate } from 'react-router-dom';

const PrivateRoute = ({ children, allowedRoles }) => {
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');

  // Check if the user is authenticated
  if (!token) {
    return <Navigate to="/login" />;
  }

  // Check if the user has the correct role
  if (!allowedRoles.includes(role)) {
    return <Navigate to="/access-denied" />;
  }

  // If authenticated and role is allowed, render the child component
  return children;
};

export default PrivateRoute;