// File: src/routes/AppRoutes.js
import { Routes, Route, Navigate } from 'react-router-dom';
import AdminDashboard from '../pages/AdminDashboard';
import DoctorDashboard from '../pages/DoctorDashboard';
import PatientDashboard from '../pages/PatientDashboard';
import Login from '../pages/Login';
import Register from '../pages/Register';
import ProtectedRoute from './ProtectedRoute';
 
const AppRoutes = () => {
  const role = localStorage.getItem('role');
 
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
 
      {/* Redirect root '/' based on role */}
      <Route
        path="/"
        element={
          role ? (
            <Navigate to={`/${role.toLowerCase()}Dashboard`} />
          ) : (
            <Navigate to="/login" />
          )
        }
      />
 
      <Route
        path="/adminDashboard"
        element={
          <ProtectedRoute allowedRoles={['ADMIN']}>
            <AdminDashboard />
          </ProtectedRoute>
        }
      />
 
      <Route
        path="/doctorDashboard"
        element={
          <ProtectedRoute allowedRoles={['DOCTOR']}>
            <DoctorDashboard />
          </ProtectedRoute>
        }
      />
 
      <Route
        path="/patientDashboard"
        element={
          <ProtectedRoute allowedRoles={['PATIENT']}>
            <PatientDashboard />
          </ProtectedRoute>
        }
      />
 
      <Route path="*" element={<h1 style={{ textAlign: 'center' }}>404 - Page Not Found</h1>} />
    </Routes>
  );
};
 
export default AppRoutes;